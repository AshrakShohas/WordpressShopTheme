<?php

	include(dirname(__FILE__)."/init.php");
	$GLOBALS['ISC_CLASS_BRANDS'] = GetClass('ISC_BRANDS');
	$GLOBALS['ISC_CLASS_BRANDS']->HandlePage();