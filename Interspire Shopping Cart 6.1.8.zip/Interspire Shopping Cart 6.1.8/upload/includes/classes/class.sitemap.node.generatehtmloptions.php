<?php

class ISC_SITEMAP_NODE_GENERATEHTMLOPTIONS
{
	public $rootClassName = '';
}
