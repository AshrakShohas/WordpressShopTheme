<?php

include(dirname(__FILE__)."/init.php");
EmailInvoiceToCustomer(2);

