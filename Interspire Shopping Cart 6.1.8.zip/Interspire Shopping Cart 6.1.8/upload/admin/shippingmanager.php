<?php
include(dirname(__FILE__)."/init.php");
GetClass('ISC_ADMIN_SHIPPINGMANAGER')->handleManager();