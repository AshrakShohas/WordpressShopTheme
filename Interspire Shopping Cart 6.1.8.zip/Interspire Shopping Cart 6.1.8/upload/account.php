<?php

	include(dirname(__FILE__)."/init.php");
	$GLOBALS['ISC_CLASS_ACCOUNT'] = GetClass('ISC_ACCOUNT');
	$GLOBALS['ISC_CLASS_ACCOUNT']->HandlePage();